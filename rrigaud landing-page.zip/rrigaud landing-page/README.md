# Richard Rigaud  Landing Page Project 'READ ME' Submission

RRIGAUD 

Completed Landing Page Project 

Used starter web page

# LANGUAGES USED:

HTML
CSS
JAVASCRIPT

# FUNCTIONS AND METHODS

- The Navigation
- STATIC TO Dynamic 
- Active Class
- CSS / Scrolling 

# Skills








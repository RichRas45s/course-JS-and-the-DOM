/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/


const sections = Array.from (document.querySelectorAll('section'));
const menu = document.getElementById ("navbar__list");
let numberOfListItems = sections.length;


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

// build the nav



function buildNav() {
    for (section of sections) {
        sectionName = section.getAttribute ('data-nav');
        sectionLink = section.getAttribute('id');

/** 
 * End Helper Functions */       /* Begin Main Functions */

       listItem =document.createElement('li');


 // add the item text

       listItem.innerHTML = `<li><a class= 'menu__link' href= "#${sectionLink}">${sectionName}</a></li>`;


  //add list item to the menu

      menu.appendChild(listItem);

}
}
//function for if section is in viewport  

  function sectionInViewPort (elem){
    let sectionPos = elem.getBoundingClientRect();
    return (section.Pos.top >=0);
};
 function toggleActiveClass() {
    for (section of sections) {
        if (!section.classlist.contains('your-active-class')){
            section.classlist.add ('your-active-class');

        } else {
        section.classList.remove('your-active-class');
    }
 }
}
buildNav();
document.addEventListener('scroll', toggleActiveClass);



// Detect the elementlocation relative to the viewport

const offset =(section) => {
    return Math.floor (section.getBoundingClientRect().top);
}

// Set sections as active

// add class active to sectiom when near top viewport
  
  const addActive=(conditional, section) => {
    if (conditional) {
      section.classList.add ('your-active-class');
      section.style.cssText= ('background-color: rgb(136,203,171');     
    };
};
  // remove  class 'active' to section when near top of viewport
  
  const removeActive = (section) => {
    section.classList.remove('your-active-class');
    section.style.cssText= ('background-color:linear-gradient(0deg, rgba(255,255,255,.1) 0%, rgba(255,255,255,.2) 100%');
    
  };
    
  
  
// implement the actual function
  
   const sectionActivation=() => {
   sections.forEach(section => {
   const elementOffset = offset(section);
    inviewport =() => elementOffset < 150 && elementOffset >= -150;
    removeActive (section);
    addActive (inviewport() , section);
  
  });
  };
  window.addEventListener ("scroll", sectionActivation);
  


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/



// Scroll to section on link click




